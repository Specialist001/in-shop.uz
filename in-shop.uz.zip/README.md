<p align="center">
    <a href="http://inshop.uz" target="_blank">inShop.uz
    </a>
    <h1 align="center">inShop.uz project</h1>
    <br>
</p>