<?php

return array(
    'host'     => 'localhost',
    'dbname'   => 'inshop_db',
    'user'     => 'root',
    'password' => '',
);