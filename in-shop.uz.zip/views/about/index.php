<?php include ROOT . '/views/layouts/header.php'; ?>
	<section>
		<div class="container">
			<div class="row">
				<div class="col-sm-4 col-sm-offset-4">
					Все материалы размещены исключительно в ознакомительных целях
				</div>			
			</div>
		</div>
	</section>

<?php include ROOT . '/views/layouts/footer.php'; ?>