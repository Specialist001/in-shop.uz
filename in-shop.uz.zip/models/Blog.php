<?php

//include ROOT . '/components/Db.php';
//use Components\Db;

class Blog
{
    public static function test()
    {
        $blog = [
            'zer'=>'0',
            'one'=>'1',
            'two'=>'2',
            'thr'=>'3',
            'fou'=>'4',
        ];

//        $blog = [
//            'zer', 'one', 'two', 'thr', 'fou',
//        ];

        return $blog;
    }
}